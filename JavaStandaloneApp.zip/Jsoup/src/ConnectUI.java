import java.awt.Font;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class ConnectUI extends JPanel {
    private static JTextField textField;
    private static JTable table;
  private static  DefaultTableModel model ;
    public static JButton submit;

    /**
     * Create the panel.
     */

    public static void main(String[] args){

        JFrame f = new JFrame();        
        f.setSize(500, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setContentPane(new ConnectUI());
        f.setVisible(true);

    }

    public ConnectUI() {

        textField = new JTextField();
        textField.setColumns(20);
      
        JLabel lblUsername = new JLabel("URL : ");
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane();

        submit = new JButton("WebCrawl");
              
        submit.addActionListener(new java.awt.event.ActionListener() {
        	public void actionPerformed(java.awt.event.ActionEvent e) {   table = new JTable();
            List<String> elementList= JsoupRun.getDomElement(textField.getText());
           List<Integer> rowCont=JsoupRun.getRowCount();
           int position = 0;
           model.setRowCount(0);
           for(int i=0;i<rowCont.size();i++){
        	   model.addRow(new Object[]{elementList.get(position++)});
        	   for(int j=0;j<rowCont.get(i);j++){
        		   model.addRow(new Object[]{"",elementList.get(position++),elementList.get(position++),elementList.get(position++),elementList.get(position++)});
        		   
        	   }
           }
           }
        	});
        
        
        GroupLayout groupLayout = new GroupLayout(this);
        groupLayout.setHorizontalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                        .addGroup(groupLayout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                .addGroup(groupLayout.createSequentialGroup()
                                    .addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                                        .addComponent(lblUsername, GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
                                        //.addComponent(lblAvailable, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addComponent(submit, GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE))
                                    .addGap(452))))
                        .addGroup(groupLayout.createSequentialGroup()
                            .addGap(196)
                           // .addComponent(lblClient, GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                            .addGap(134)))
                    .addGap(38))
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(200)
                   // .addComponent(submit, GroupLayout.DEFAULT_SIZE, 12, Short.MAX_VALUE)
                    .addGap(198))
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(68)
                 //   .addComponent(lblWarning, GroupLayout.DEFAULT_SIZE, 357, Short.MAX_VALUE)
                    .addGap(75))
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(100)
                    .addComponent(textField, 100, 250, Short.MAX_VALUE)
                    .addGap(130))
        );
        groupLayout.setVerticalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addContainerGap()
                   // .addComponent(lblClient, GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
                        .addGroup(groupLayout.createSequentialGroup()
                            .addGap(31)
                            .addComponent(lblUsername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGroup(groupLayout.createSequentialGroup()
                            //.addPreferredGap(ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        		.addGap(31)
                            .addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                    .addPreferredGap(ComponentPlacement.RELATED)
                    //.addComponent(lblAvailable, GroupLayout.DEFAULT_SIZE, 4, Short.MAX_VALUE)
                    .addComponent(submit, GroupLayout.DEFAULT_SIZE, 31, 31)
                    .addGap(18)
                    .addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                    .addGap(37)
                    //.addComponent(lblWarning, GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                    .addPreferredGap(ComponentPlacement.RELATED))
                   // .addComponent(submit, GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                 //   .addGap(69))
        );

        table = new JTable();
       model = new DefaultTableModel();
       table.setModel(model);
       model.addColumn("FORM NAME");
       model.addColumn("NAME");
       model.addColumn("ID");
       model.addColumn("TYPE");
       model.addColumn("VALUE");
       
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);
        setLayout(groupLayout);

    }

}