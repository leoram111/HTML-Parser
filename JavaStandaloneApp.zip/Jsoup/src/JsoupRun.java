import java.io.IOException;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JsoupRun {
	private static List<Integer> rowCount;//= new ArrayList<>();
	public static void main(String[] args)  {
		String url="http://164.99.86.160/test/policy/forms2.html";
		
		
		System.out.println(getDomElement(url));
	}
	public static List<Integer> getRowCount(){
		return rowCount;
}

	public static List<String> getDomElement(String url) {
		Document d;
		List<String> list= new ArrayList<>();
		rowCount = new ArrayList<>();
		
		try {
			d = Jsoup.connect(url).userAgent("mozilla/17.0").timeout(6000).get();
			int fid=0;
			for (Element ele : d.select("form")) {
				fid++;
				String formid = ele.select("form").attr("id");
				if (formid.isEmpty())
					formid = "Form"+fid;

				rowCount.add(ele.select("input").size());
				list.add(formid);
				for (Element element : ele.select("input")) {
					
					list.add(element.select("input").attr("name"));
					list.add(element.select("input").attr("id"));
					list.add(element.select("input").attr("type"));
					list.add(element.select("input").attr("value"));
					
				}
				
			for(String key:list){
				System.out.println(key );
			}


			}
			System.out.println("List size is "+ list.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}