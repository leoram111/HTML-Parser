chrome.runtime.onMessage.addListener(function(request, sender) {
  if (request.action == "getSource") {
    message.innerHTML = parseSourceForForms( request.source);
  }
});

function onWindowLoad() {
  var message = document.querySelector('#message');

  chrome.tabs.executeScript(null, {
    file: "getPagesSource.js"
  }, function() {
    // If you try and inject into an extensions page or the webstore/NTP you'll get an error
    if (chrome.runtime.lastError) {
      message.innerText = 'There was an error injecting script : <br/>' + chrome.runtime.lastError.message;
    }
  });
}

function parseSourceForForms( pageSrc) {
  var result = " ";

  var htmlObject = document.createElement('div');
  htmlObject.innerHTML = pageSrc;

  // All forms element of the page.
  var forms = htmlObject.getElementsByTagName('form');

  // Check if any form is present in the page.
  //if ( forms.length == 0 ) {
    //result += '<p>' + typeof forms.length + '</p>';
    //result += '<p><strong>Sorry, but could not found any forms here. Are you sure you are on right tab?</strong></p>';
  //} else {
    // Parsing input element for each form.
    for ( var i = 0; i < forms.length; i++){
      result += '<table style="width:100%" border="2">';
      result += '<tr><th colspan="4" style="border:0">Form</th></tr>';
      result += '<tr><th colspan="2">Name</th><th colspan="2">ID</th></tr>';
      result += '<tr><td colspan="2">' + forms[i].name + '</td><td colspan="2">' + forms[i].id + '</td></tr>';

      var inputs = forms[i].getElementsByTagName('input');
      result += '<tr><th colspan="4" style="border:0">Inputs</th></tr>';
      result += '<tr><th>Type</th><th>Name</th><th>ID</th><th>Value</th></tr>';
      for ( var j = 0; j < inputs.length; j++){
        result += '<tr><td>' + inputs[j].type + '</td><td>' + inputs[j].name + '</td><td>' + inputs[j].id + '</td><td>' + inputs[j].value + '</td></tr>';
        //result += '<br/>' + inputs[j].id + '-' + inputs[j].name + '-' + inputs[j].type;
      }
      result += '</table><br/>';
    }
  //}
  result += '<br/><p> Total number of forms found in the page : ' + forms.length + '</p>';

  return result;
}

window.onload = onWindowLoad;
